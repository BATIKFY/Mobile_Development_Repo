# Batikfy

Android mobile application with minimum API 21 that can detect Batik patterns. Not only that, this app have game features and recomendation marketplace to buy Batik.
