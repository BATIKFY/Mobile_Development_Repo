package com.batikfy.batikfy.ui.detail.batik

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.batikfy.batikfy.R

class DetailBatikActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_batik)
    }
}