package com.batikfy.batikfy.ui.auth.register

import androidx.lifecycle.ViewModel
import com.batikfy.batikfy.data.BatikfyRepository

class RegisterViewModel(private val batikfyrepository: BatikfyRepository) : ViewModel() {
}