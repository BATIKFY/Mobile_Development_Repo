package com.batikfy.batikfy.model

import com.batikfy.batikfy.data.remote.response.BlogsItem

object ArticleDataDummy {
    private var articleList = listOf(
        BlogsItem(
            "1",
            "Ini nomor Satu",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras interdum odio non dui imperdiet, a varius dui placerat. In dapibus interdum ante a tempor. Proin quis libero risus. Aliquam imperdiet eu turpis sed euismod. Aliquam elementum dui in sem lobortis, eu sollicitudin purus rhoncus. Maecenas eget pellentesque ipsum, et rhoncus orci. Cras quis commodo velit. Vestibulum lorem odio, malesuada fermentum gravida ut, porta fermentum odio. Proin non libero vitae purus blandit luctus at vel enim. Morbi mollis dolor est, id lacinia urna tincidunt vitae. Aenean nisl elit, venenatis eget tincidunt vitae, tempus ut sem. Vivamus cursus, est id posuere rutrum, arcu neque bibendum libero, sit amet pellentesque erat nisi et leo. Aliquam nec tortor vel nunc facilisis scelerisque et vel nunc. Vestibulum tristique rhoncus ligula sed mattis. Phasellus scelerisque metus non ullamcorper viverra.\n" +
                    "\n" +
                    "Pellentesque enim urna, blandit vitae feugiat non, lobortis ut sem. Integer vel interdum arcu. Aliquam convallis euismod lorem, et volutpat mauris iaculis non. Donec a purus maximus, imperdiet nisi in, suscipit ante. Vivamus auctor erat lacus. Phasellus et velit ut lacus ullamcorper eleifend. In diam velit, posuere et aliquam nec, consectetur sed orci.\n" +
                    "\n" +
                    "Suspendisse ac lacus ut ex ullamcorper auctor. Aenean leo magna, sagittis at aliquam a, egestas vel dolor. Maecenas vehicula efficitur lacus in bibendum. Nunc a diam sapien. Fusce gravida sit amet enim a imperdiet. Sed laoreet nisl eget velit dignissim, et vehicula nisi sollicitudin. Cras eu erat nisi. In eu nibh nulla. Donec pharetra tincidunt sem in rhoncus. Nulla facilisi. Vestibulum tempor, lectus eu auctor pretium, sem enim feugiat ipsum, eleifend maximus mauris nibh ac augue. Aliquam vitae pellentesque eros. Quisque porttitor accumsan gravida. Vestibulum gravida odio quis nunc aliquam, at tempor mauris feugiat. Mauris placerat, risus eget volutpat interdum, turpis metus iaculis dolor, non elementum nisl augue quis nibh. Maecenas nisi ex, luctus.",
            "https://www.lipsum.com/feed/html",
            "https://drive.google.com/file/d/11n9RswqPrmepthD-pa9UdRup12OtCPHp/view?usp=share_link",
        ),
        BlogsItem(
            "2",
            "This is number two",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras interdum odio non dui imperdiet, a varius dui placerat. In dapibus interdum ante a tempor. Proin quis libero risus. Aliquam imperdiet eu turpis sed euismod. Aliquam elementum dui in sem lobortis, eu sollicitudin purus rhoncus. Maecenas eget pellentesque ipsum, et rhoncus orci. Cras quis commodo velit. Vestibulum lorem odio, malesuada fermentum gravida ut, porta fermentum odio. Proin non libero vitae purus blandit luctus at vel enim. Morbi mollis dolor est, id lacinia urna tincidunt vitae. Aenean nisl elit, venenatis eget tincidunt vitae, tempus ut sem. Vivamus cursus, est id posuere rutrum, arcu neque bibendum libero, sit amet pellentesque erat nisi et leo. Aliquam nec tortor vel nunc facilisis scelerisque et vel nunc. Vestibulum tristique rhoncus ligula sed mattis. Phasellus scelerisque metus non ullamcorper viverra.\n" +
                    "\n" +
                    "Pellentesque enim urna, blandit vitae feugiat non, lobortis ut sem. Integer vel interdum arcu. Aliquam convallis euismod lorem, et volutpat mauris iaculis non. Donec a purus maximus, imperdiet nisi in, suscipit ante. Vivamus auctor erat lacus. Phasellus et velit ut lacus ullamcorper eleifend. In diam velit, posuere et aliquam nec, consectetur sed orci.\n" +
                    "\n" +
                    "Suspendisse ac lacus ut ex ullamcorper auctor. Aenean leo magna, sagittis at aliquam a, egestas vel dolor. Maecenas vehicula efficitur lacus in bibendum. Nunc a diam sapien. Fusce gravida sit amet enim a imperdiet. Sed laoreet nisl eget velit dignissim, et vehicula nisi sollicitudin. Cras eu erat nisi. In eu nibh nulla. Donec pharetra tincidunt sem in rhoncus. Nulla facilisi. Vestibulum tempor, lectus eu auctor pretium, sem enim feugiat ipsum, eleifend maximus mauris nibh ac augue. Aliquam vitae pellentesque eros. Quisque porttitor accumsan gravida. Vestibulum gravida odio quis nunc aliquam, at tempor mauris feugiat. Mauris placerat, risus eget volutpat interdum, turpis metus iaculis dolor, non elementum nisl augue quis nibh. Maecenas nisi ex, luctus.",
            "https://www.lipsum.com/feed/html",
            "https://drive.google.com/file/d/11n9RswqPrmepthD-pa9UdRup12OtCPHp/view?usp=share_link",
        ),
        BlogsItem(
            "3",
            "Ini nomor 3",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras interdum odio non dui imperdiet, a varius dui placerat. In dapibus interdum ante a tempor. Proin quis libero risus. Aliquam imperdiet eu turpis sed euismod. Aliquam elementum dui in sem lobortis, eu sollicitudin purus rhoncus. Maecenas eget pellentesque ipsum, et rhoncus orci. Cras quis commodo velit. Vestibulum lorem odio, malesuada fermentum gravida ut, porta fermentum odio. Proin non libero vitae purus blandit luctus at vel enim. Morbi mollis dolor est, id lacinia urna tincidunt vitae. Aenean nisl elit, venenatis eget tincidunt vitae, tempus ut sem. Vivamus cursus, est id posuere rutrum, arcu neque bibendum libero, sit amet pellentesque erat nisi et leo. Aliquam nec tortor vel nunc facilisis scelerisque et vel nunc. Vestibulum tristique rhoncus ligula sed mattis. Phasellus scelerisque metus non ullamcorper viverra.\n" +
                    "\n" +
                    "Pellentesque enim urna, blandit vitae feugiat non, lobortis ut sem. Integer vel interdum arcu. Aliquam convallis euismod lorem, et volutpat mauris iaculis non. Donec a purus maximus, imperdiet nisi in, suscipit ante. Vivamus auctor erat lacus. Phasellus et velit ut lacus ullamcorper eleifend. In diam velit, posuere et aliquam nec, consectetur sed orci.\n" +
                    "\n" +
                    "Suspendisse ac lacus ut ex ullamcorper auctor. Aenean leo magna, sagittis at aliquam a, egestas vel dolor. Maecenas vehicula efficitur lacus in bibendum. Nunc a diam sapien. Fusce gravida sit amet enim a imperdiet. Sed laoreet nisl eget velit dignissim, et vehicula nisi sollicitudin. Cras eu erat nisi. In eu nibh nulla. Donec pharetra tincidunt sem in rhoncus. Nulla facilisi. Vestibulum tempor, lectus eu auctor pretium, sem enim feugiat ipsum, eleifend maximus mauris nibh ac augue. Aliquam vitae pellentesque eros. Quisque porttitor accumsan gravida. Vestibulum gravida odio quis nunc aliquam, at tempor mauris feugiat. Mauris placerat, risus eget volutpat interdum, turpis metus iaculis dolor, non elementum nisl augue quis nibh. Maecenas nisi ex, luctus.",
            "https://www.lipsum.com/feed/html",
            "https://drive.google.com/file/d/11n9RswqPrmepthD-pa9UdRup12OtCPHp/view?usp=share_link",
        ),
        BlogsItem(
            "4",
            "This is number four",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras interdum odio non dui imperdiet, a varius dui placerat. In dapibus interdum ante a tempor. Proin quis libero risus. Aliquam imperdiet eu turpis sed euismod. Aliquam elementum dui in sem lobortis, eu sollicitudin purus rhoncus. Maecenas eget pellentesque ipsum, et rhoncus orci. Cras quis commodo velit. Vestibulum lorem odio, malesuada fermentum gravida ut, porta fermentum odio. Proin non libero vitae purus blandit luctus at vel enim. Morbi mollis dolor est, id lacinia urna tincidunt vitae. Aenean nisl elit, venenatis eget tincidunt vitae, tempus ut sem. Vivamus cursus, est id posuere rutrum, arcu neque bibendum libero, sit amet pellentesque erat nisi et leo. Aliquam nec tortor vel nunc facilisis scelerisque et vel nunc. Vestibulum tristique rhoncus ligula sed mattis. Phasellus scelerisque metus non ullamcorper viverra.\n" +
                    "\n" +
                    "Pellentesque enim urna, blandit vitae feugiat non, lobortis ut sem. Integer vel interdum arcu. Aliquam convallis euismod lorem, et volutpat mauris iaculis non. Donec a purus maximus, imperdiet nisi in, suscipit ante. Vivamus auctor erat lacus. Phasellus et velit ut lacus ullamcorper eleifend. In diam velit, posuere et aliquam nec, consectetur sed orci.\n" +
                    "\n" +
                    "Suspendisse ac lacus ut ex ullamcorper auctor. Aenean leo magna, sagittis at aliquam a, egestas vel dolor. Maecenas vehicula efficitur lacus in bibendum. Nunc a diam sapien. Fusce gravida sit amet enim a imperdiet. Sed laoreet nisl eget velit dignissim, et vehicula nisi sollicitudin. Cras eu erat nisi. In eu nibh nulla. Donec pharetra tincidunt sem in rhoncus. Nulla facilisi. Vestibulum tempor, lectus eu auctor pretium, sem enim feugiat ipsum, eleifend maximus mauris nibh ac augue. Aliquam vitae pellentesque eros. Quisque porttitor accumsan gravida. Vestibulum gravida odio quis nunc aliquam, at tempor mauris feugiat. Mauris placerat, risus eget volutpat interdum, turpis metus iaculis dolor, non elementum nisl augue quis nibh. Maecenas nisi ex, luctus.",
            "https://www.lipsum.com/feed/html",
            "https://drive.google.com/file/d/11n9RswqPrmepthD-pa9UdRup12OtCPHp/view?usp=share_link",
        ),
        BlogsItem(
            "5",
            "Ini nomor 5",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras interdum odio non dui imperdiet, a varius dui placerat. In dapibus interdum ante a tempor. Proin quis libero risus. Aliquam imperdiet eu turpis sed euismod. Aliquam elementum dui in sem lobortis, eu sollicitudin purus rhoncus. Maecenas eget pellentesque ipsum, et rhoncus orci. Cras quis commodo velit. Vestibulum lorem odio, malesuada fermentum gravida ut, porta fermentum odio. Proin non libero vitae purus blandit luctus at vel enim. Morbi mollis dolor est, id lacinia urna tincidunt vitae. Aenean nisl elit, venenatis eget tincidunt vitae, tempus ut sem. Vivamus cursus, est id posuere rutrum, arcu neque bibendum libero, sit amet pellentesque erat nisi et leo. Aliquam nec tortor vel nunc facilisis scelerisque et vel nunc. Vestibulum tristique rhoncus ligula sed mattis. Phasellus scelerisque metus non ullamcorper viverra.\n" +
                    "\n" +
                    "Pellentesque enim urna, blandit vitae feugiat non, lobortis ut sem. Integer vel interdum arcu. Aliquam convallis euismod lorem, et volutpat mauris iaculis non. Donec a purus maximus, imperdiet nisi in, suscipit ante. Vivamus auctor erat lacus. Phasellus et velit ut lacus ullamcorper eleifend. In diam velit, posuere et aliquam nec, consectetur sed orci.\n" +
                    "\n" +
                    "Suspendisse ac lacus ut ex ullamcorper auctor. Aenean leo magna, sagittis at aliquam a, egestas vel dolor. Maecenas vehicula efficitur lacus in bibendum. Nunc a diam sapien. Fusce gravida sit amet enim a imperdiet. Sed laoreet nisl eget velit dignissim, et vehicula nisi sollicitudin. Cras eu erat nisi. In eu nibh nulla. Donec pharetra tincidunt sem in rhoncus. Nulla facilisi. Vestibulum tempor, lectus eu auctor pretium, sem enim feugiat ipsum, eleifend maximus mauris nibh ac augue. Aliquam vitae pellentesque eros. Quisque porttitor accumsan gravida. Vestibulum gravida odio quis nunc aliquam, at tempor mauris feugiat. Mauris placerat, risus eget volutpat interdum, turpis metus iaculis dolor, non elementum nisl augue quis nibh. Maecenas nisi ex, luctus.",
            "https://www.lipsum.com/feed/html",
            "https://drive.google.com/file/d/11n9RswqPrmepthD-pa9UdRup12OtCPHp/view?usp=share_link",
        ),
        BlogsItem(
            "6",
            "This is number six",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras interdum odio non dui imperdiet, a varius dui placerat. In dapibus interdum ante a tempor. Proin quis libero risus. Aliquam imperdiet eu turpis sed euismod. Aliquam elementum dui in sem lobortis, eu sollicitudin purus rhoncus. Maecenas eget pellentesque ipsum, et rhoncus orci. Cras quis commodo velit. Vestibulum lorem odio, malesuada fermentum gravida ut, porta fermentum odio. Proin non libero vitae purus blandit luctus at vel enim. Morbi mollis dolor est, id lacinia urna tincidunt vitae. Aenean nisl elit, venenatis eget tincidunt vitae, tempus ut sem. Vivamus cursus, est id posuere rutrum, arcu neque bibendum libero, sit amet pellentesque erat nisi et leo. Aliquam nec tortor vel nunc facilisis scelerisque et vel nunc. Vestibulum tristique rhoncus ligula sed mattis. Phasellus scelerisque metus non ullamcorper viverra.\n" +
                    "\n" +
                    "Pellentesque enim urna, blandit vitae feugiat non, lobortis ut sem. Integer vel interdum arcu. Aliquam convallis euismod lorem, et volutpat mauris iaculis non. Donec a purus maximus, imperdiet nisi in, suscipit ante. Vivamus auctor erat lacus. Phasellus et velit ut lacus ullamcorper eleifend. In diam velit, posuere et aliquam nec, consectetur sed orci.\n" +
                    "\n" +
                    "Suspendisse ac lacus ut ex ullamcorper auctor. Aenean leo magna, sagittis at aliquam a, egestas vel dolor. Maecenas vehicula efficitur lacus in bibendum. Nunc a diam sapien. Fusce gravida sit amet enim a imperdiet. Sed laoreet nisl eget velit dignissim, et vehicula nisi sollicitudin. Cras eu erat nisi. In eu nibh nulla. Donec pharetra tincidunt sem in rhoncus. Nulla facilisi. Vestibulum tempor, lectus eu auctor pretium, sem enim feugiat ipsum, eleifend maximus mauris nibh ac augue. Aliquam vitae pellentesque eros. Quisque porttitor accumsan gravida. Vestibulum gravida odio quis nunc aliquam, at tempor mauris feugiat. Mauris placerat, risus eget volutpat interdum, turpis metus iaculis dolor, non elementum nisl augue quis nibh. Maecenas nisi ex, luctus.",
            "https://www.lipsum.com/feed/html",
            "https://drive.google.com/file/d/11n9RswqPrmepthD-pa9UdRup12OtCPHp/view?usp=share_link",
        ),
        BlogsItem(
            "7",
            "Ini nomor 7",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras interdum odio non dui imperdiet, a varius dui placerat. In dapibus interdum ante a tempor. Proin quis libero risus. Aliquam imperdiet eu turpis sed euismod. Aliquam elementum dui in sem lobortis, eu sollicitudin purus rhoncus. Maecenas eget pellentesque ipsum, et rhoncus orci. Cras quis commodo velit. Vestibulum lorem odio, malesuada fermentum gravida ut, porta fermentum odio. Proin non libero vitae purus blandit luctus at vel enim. Morbi mollis dolor est, id lacinia urna tincidunt vitae. Aenean nisl elit, venenatis eget tincidunt vitae, tempus ut sem. Vivamus cursus, est id posuere rutrum, arcu neque bibendum libero, sit amet pellentesque erat nisi et leo. Aliquam nec tortor vel nunc facilisis scelerisque et vel nunc. Vestibulum tristique rhoncus ligula sed mattis. Phasellus scelerisque metus non ullamcorper viverra.\n" +
                    "\n" +
                    "Pellentesque enim urna, blandit vitae feugiat non, lobortis ut sem. Integer vel interdum arcu. Aliquam convallis euismod lorem, et volutpat mauris iaculis non. Donec a purus maximus, imperdiet nisi in, suscipit ante. Vivamus auctor erat lacus. Phasellus et velit ut lacus ullamcorper eleifend. In diam velit, posuere et aliquam nec, consectetur sed orci.\n" +
                    "\n" +
                    "Suspendisse ac lacus ut ex ullamcorper auctor. Aenean leo magna, sagittis at aliquam a, egestas vel dolor. Maecenas vehicula efficitur lacus in bibendum. Nunc a diam sapien. Fusce gravida sit amet enim a imperdiet. Sed laoreet nisl eget velit dignissim, et vehicula nisi sollicitudin. Cras eu erat nisi. In eu nibh nulla. Donec pharetra tincidunt sem in rhoncus. Nulla facilisi. Vestibulum tempor, lectus eu auctor pretium, sem enim feugiat ipsum, eleifend maximus mauris nibh ac augue. Aliquam vitae pellentesque eros. Quisque porttitor accumsan gravida. Vestibulum gravida odio quis nunc aliquam, at tempor mauris feugiat. Mauris placerat, risus eget volutpat interdum, turpis metus iaculis dolor, non elementum nisl augue quis nibh. Maecenas nisi ex, luctus.",
            "https://www.lipsum.com/feed/html",
            "https://drive.google.com/file/d/11n9RswqPrmepthD-pa9UdRup12OtCPHp/view?usp=share_link",
        ),
        BlogsItem(
            "8",
            "This is number eight",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras interdum odio non dui imperdiet, a varius dui placerat. In dapibus interdum ante a tempor. Proin quis libero risus. Aliquam imperdiet eu turpis sed euismod. Aliquam elementum dui in sem lobortis, eu sollicitudin purus rhoncus. Maecenas eget pellentesque ipsum, et rhoncus orci. Cras quis commodo velit. Vestibulum lorem odio, malesuada fermentum gravida ut, porta fermentum odio. Proin non libero vitae purus blandit luctus at vel enim. Morbi mollis dolor est, id lacinia urna tincidunt vitae. Aenean nisl elit, venenatis eget tincidunt vitae, tempus ut sem. Vivamus cursus, est id posuere rutrum, arcu neque bibendum libero, sit amet pellentesque erat nisi et leo. Aliquam nec tortor vel nunc facilisis scelerisque et vel nunc. Vestibulum tristique rhoncus ligula sed mattis. Phasellus scelerisque metus non ullamcorper viverra.\n" +
                    "\n" +
                    "Pellentesque enim urna, blandit vitae feugiat non, lobortis ut sem. Integer vel interdum arcu. Aliquam convallis euismod lorem, et volutpat mauris iaculis non. Donec a purus maximus, imperdiet nisi in, suscipit ante. Vivamus auctor erat lacus. Phasellus et velit ut lacus ullamcorper eleifend. In diam velit, posuere et aliquam nec, consectetur sed orci.\n" +
                    "\n" +
                    "Suspendisse ac lacus ut ex ullamcorper auctor. Aenean leo magna, sagittis at aliquam a, egestas vel dolor. Maecenas vehicula efficitur lacus in bibendum. Nunc a diam sapien. Fusce gravida sit amet enim a imperdiet. Sed laoreet nisl eget velit dignissim, et vehicula nisi sollicitudin. Cras eu erat nisi. In eu nibh nulla. Donec pharetra tincidunt sem in rhoncus. Nulla facilisi. Vestibulum tempor, lectus eu auctor pretium, sem enim feugiat ipsum, eleifend maximus mauris nibh ac augue. Aliquam vitae pellentesque eros. Quisque porttitor accumsan gravida. Vestibulum gravida odio quis nunc aliquam, at tempor mauris feugiat. Mauris placerat, risus eget volutpat interdum, turpis metus iaculis dolor, non elementum nisl augue quis nibh. Maecenas nisi ex, luctus.",
            "https://www.lipsum.com/feed/html",
            "https://drive.google.com/file/d/11n9RswqPrmepthD-pa9UdRup12OtCPHp/view?usp=share_link",
        ),
        BlogsItem(
            "9",
            "Ini nomor 9",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras interdum odio non dui imperdiet, a varius dui placerat. In dapibus interdum ante a tempor. Proin quis libero risus. Aliquam imperdiet eu turpis sed euismod. Aliquam elementum dui in sem lobortis, eu sollicitudin purus rhoncus. Maecenas eget pellentesque ipsum, et rhoncus orci. Cras quis commodo velit. Vestibulum lorem odio, malesuada fermentum gravida ut, porta fermentum odio. Proin non libero vitae purus blandit luctus at vel enim. Morbi mollis dolor est, id lacinia urna tincidunt vitae. Aenean nisl elit, venenatis eget tincidunt vitae, tempus ut sem. Vivamus cursus, est id posuere rutrum, arcu neque bibendum libero, sit amet pellentesque erat nisi et leo. Aliquam nec tortor vel nunc facilisis scelerisque et vel nunc. Vestibulum tristique rhoncus ligula sed mattis. Phasellus scelerisque metus non ullamcorper viverra.\n" +
                    "\n" +
                    "Pellentesque enim urna, blandit vitae feugiat non, lobortis ut sem. Integer vel interdum arcu. Aliquam convallis euismod lorem, et volutpat mauris iaculis non. Donec a purus maximus, imperdiet nisi in, suscipit ante. Vivamus auctor erat lacus. Phasellus et velit ut lacus ullamcorper eleifend. In diam velit, posuere et aliquam nec, consectetur sed orci.\n" +
                    "\n" +
                    "Suspendisse ac lacus ut ex ullamcorper auctor. Aenean leo magna, sagittis at aliquam a, egestas vel dolor. Maecenas vehicula efficitur lacus in bibendum. Nunc a diam sapien. Fusce gravida sit amet enim a imperdiet. Sed laoreet nisl eget velit dignissim, et vehicula nisi sollicitudin. Cras eu erat nisi. In eu nibh nulla. Donec pharetra tincidunt sem in rhoncus. Nulla facilisi. Vestibulum tempor, lectus eu auctor pretium, sem enim feugiat ipsum, eleifend maximus mauris nibh ac augue. Aliquam vitae pellentesque eros. Quisque porttitor accumsan gravida. Vestibulum gravida odio quis nunc aliquam, at tempor mauris feugiat. Mauris placerat, risus eget volutpat interdum, turpis metus iaculis dolor, non elementum nisl augue quis nibh. Maecenas nisi ex, luctus.",
            "https://www.lipsum.com/feed/html",
            "https://drive.google.com/file/d/11n9RswqPrmepthD-pa9UdRup12OtCPHp/view?usp=share_link",
        ),
        BlogsItem(
            "10",
            "This is number ten",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras interdum odio non dui imperdiet, a varius dui placerat. In dapibus interdum ante a tempor. Proin quis libero risus. Aliquam imperdiet eu turpis sed euismod. Aliquam elementum dui in sem lobortis, eu sollicitudin purus rhoncus. Maecenas eget pellentesque ipsum, et rhoncus orci. Cras quis commodo velit. Vestibulum lorem odio, malesuada fermentum gravida ut, porta fermentum odio. Proin non libero vitae purus blandit luctus at vel enim. Morbi mollis dolor est, id lacinia urna tincidunt vitae. Aenean nisl elit, venenatis eget tincidunt vitae, tempus ut sem. Vivamus cursus, est id posuere rutrum, arcu neque bibendum libero, sit amet pellentesque erat nisi et leo. Aliquam nec tortor vel nunc facilisis scelerisque et vel nunc. Vestibulum tristique rhoncus ligula sed mattis. Phasellus scelerisque metus non ullamcorper viverra.\n" +
                    "\n" +
                    "Pellentesque enim urna, blandit vitae feugiat non, lobortis ut sem. Integer vel interdum arcu. Aliquam convallis euismod lorem, et volutpat mauris iaculis non. Donec a purus maximus, imperdiet nisi in, suscipit ante. Vivamus auctor erat lacus. Phasellus et velit ut lacus ullamcorper eleifend. In diam velit, posuere et aliquam nec, consectetur sed orci.\n" +
                    "\n" +
                    "Suspendisse ac lacus ut ex ullamcorper auctor. Aenean leo magna, sagittis at aliquam a, egestas vel dolor. Maecenas vehicula efficitur lacus in bibendum. Nunc a diam sapien. Fusce gravida sit amet enim a imperdiet. Sed laoreet nisl eget velit dignissim, et vehicula nisi sollicitudin. Cras eu erat nisi. In eu nibh nulla. Donec pharetra tincidunt sem in rhoncus. Nulla facilisi. Vestibulum tempor, lectus eu auctor pretium, sem enim feugiat ipsum, eleifend maximus mauris nibh ac augue. Aliquam vitae pellentesque eros. Quisque porttitor accumsan gravida. Vestibulum gravida odio quis nunc aliquam, at tempor mauris feugiat. Mauris placerat, risus eget volutpat interdum, turpis metus iaculis dolor, non elementum nisl augue quis nibh. Maecenas nisi ex, luctus.",
            "https://www.lipsum.com/feed/html",
            "https://drive.google.com/file/d/11n9RswqPrmepthD-pa9UdRup12OtCPHp/view?usp=share_link",
        ),
    )

    fun getData(): List<BlogsItem> {
        return articleList
    }
}